# luciferase
Helper functions for luciferase data
